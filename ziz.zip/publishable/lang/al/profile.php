<?php

return [
    'avatar'        => 'Avatari',
    'edit'          => 'Edit My Profile',
    'edit_user'     => 'Edit User',
    'password'      => 'Fjalëkalimi',
    'password_hint' => 'Lëreni bosh për të mbajtur të njëjtën',
    'role'          => 'Roli',
    'user_role'     => 'Roli i përdoruesit',
];
