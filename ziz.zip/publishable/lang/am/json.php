<?php

return [
    'invalid'           => 'Անվավեր JSON',
    'invalid_message'   => 'Կարծես թե ներկայացրել եք ինչ որ անվավել JSON.',
    'valid'             => 'Վավեր JSON',
    'validation_errors' => 'Վավերացման սխալներ',
];
