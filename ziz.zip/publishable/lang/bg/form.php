<?php

return [
    'field_password_keep'          => 'Оставете празно за да запазите същата стойност',
    'field_select_dd_relationship' => 'Моля създайте правилната връзка в :method метода на :class класа.',
    'type_checkbox'                => 'Kвадратче за Oтметка',
    'type_codeeditor'              => 'Редактор на код',
    'type_file'                    => 'Файл',
    'type_image'                   => 'Изображение',
    'type_radiobutton'             => 'Радио Бутон',
    'type_richtextbox'             => 'Текстови редактор',
    'type_selectdropdown'          => 'Падащо меню',
    'type_textarea'                => 'Текстово област',
    'type_textbox'                 => 'Текстово поле',
];
