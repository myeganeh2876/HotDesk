<?php

return [
    'field_password_keep'          => 'Deixar buit per mantenir el mateix',
    'field_select_dd_relationship' => 'Assegura\'t de crear la relació apropiada en el mètode :method de la clase :class.',
    'type_checkbox'                => 'Casella de verificació',
    'type_codeeditor'              => 'Editor de codi',
    'type_file'                    => 'Arxiu',
    'type_image'                   => 'Imatge',
    'type_radiobutton'             => 'Botó de radi',
    'type_richtextbox'             => 'Caixa de text enriquit',
    'type_selectdropdown'          => 'Seleccionar Desplegable',
    'type_textarea'                => 'Àrea de text',
    'type_textbox'                 => 'Caixa de text',
];
