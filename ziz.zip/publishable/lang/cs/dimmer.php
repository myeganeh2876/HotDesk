<?php

return [
    'page'           => 'Stránek|Stránky',
    'page_link_text' => 'Zobrazit všechny stránky',
    'page_text'      => 'Máte :count :string ve vaší databázi. Klikněte na tlačítko níže pro zobrazení všech stránek.',
    'post'           => 'Příspěvků|Příspěvků',
    'post_link_text' => 'Zobrazit všechny příspěvky',
    'post_text'      => 'Máte :count :string ve vaší databázi. Klikněte na tlačítko níže pro zobrazení všech příspěvků.',
    'user'           => 'Uživatelů|Uživatelů',
    'user_link_text' => 'Zobrazit všechny uživatele',
    'user_text'      => 'Máte :count :string ve vaší databázi. Klikněte na tlačítko níže pro zobrazení všech uživatelů.',
];
