<?php

return [
    'last_week' => 'Letzte Woche',
    'last_year' => 'Letztes Jahr',
    'this_week' => 'Diese Woche',
    'this_year' => 'Dieses Jahr',
];
