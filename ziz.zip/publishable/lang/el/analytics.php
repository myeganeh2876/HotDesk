<?php

return [
    'by_pageview'            => 'Ανά εμφάνιση σελίδας',
    'by_sessions'            => 'Ανά συνεδρία',
    'by_users'               => 'Ανά χρήστες',
    'no_client_id'           => 'Για να δείτε στατιστικά θα πρέπει να πάρετε το google analytics client id και να το προσθέσετε στις ρυθμίσεις για το κλειδί <code>google_analytics_client_id</code>. Πάρτε το κλειδί σας από την Google developer console:',
    'set_view'               => 'Διαλέξτε τύπο εμφάνισης',
    'this_vs_last_week'      => 'Σύγκριση αυτής της εβδομάδας με την προηγούμενη',
    'this_vs_last_year'      => 'Σύγκριση αυτού του έτους με το προηγούμενο',
    'top_browsers'           => 'Κορυφαίοι Browsers',
    'top_countries'          => 'Κορυφαίες χώρες',
    'various_visualizations' => 'Διάφορες οπτικοποιήσεις',
];
