<?php

return [
    'loggingin'    => 'Logging in',
    'signin_below' => 'Κάντε σύνδεση παρακάτω:',
    'welcome'      => 'Καλωσήρθατε στο Voyager. Τον πίνακα διαχείρισης που έλειπε από το Laravel',
];
