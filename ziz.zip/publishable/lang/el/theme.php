<?php

return [
    'footer_copyright'  => 'Δημιουργήθηκε με <i class="voyager-heart"></i> από το',
    'footer_copyright2' => 'Δημιουργήθηκε με ρούμι και ακόμα περισσότερο ρούμι',
];
