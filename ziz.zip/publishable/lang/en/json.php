<?php

return [
    'invalid'           => 'Invalid JSON',
    'invalid_message'   => 'Seems like you introduced some invalid JSON.',
    'valid'             => 'Valid JSON',
    'validation_errors' => 'Validation errors',
];
