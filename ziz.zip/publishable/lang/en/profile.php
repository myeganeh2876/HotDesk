<?php

return [
    'avatar'           => 'Avatar',
    'edit'             => 'Edit My Profile',
    'edit_user'        => 'Edit User',
    'password'         => 'Password',
    'password_hint'    => 'Leave empty to keep the same',
    'role'             => 'Role',
    'roles'            => 'Roles',
    'role_default'     => 'Default Role',
    'roles_additional' => 'Additional Roles',
    'user_role'        => 'User Role',
];
