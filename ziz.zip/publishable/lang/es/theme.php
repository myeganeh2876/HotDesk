<?php

return [
    'footer_copyright'  => 'Hecho con <i class = "voyager-heart"> </i> por',
    'footer_copyright2' => 'Hecho con ron e incluso más ron',
];
