<?php

return [
    'field_password_keep'          => 'برای یکسان بودن خالی بگذارید',
    'field_select_dd_relationship' => 'از تنظیم مناسب ارتباط در متن :method از کلاس :class اطمینان حاصل کنید.',

    'type_checkbox'                => 'چک باکس',
    'type_codeeditor'              => 'ویرایشگر کد',
    'type_file'                    => 'فایل',
    'type_image'                   => 'تصویر',
    'type_radiobutton'             => 'دکمه رادیویی',
    'type_richtextbox'             => 'ویرایشگر متن',
    'type_selectdropdown'          => 'انتخابگر کشویی',
    'type_textarea'                => 'فضای متنی',
    'type_textbox'                 => 'قسمت متنی',
];
