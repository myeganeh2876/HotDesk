<?php

return [
    'by_pageview'  => 'Sivunäyttöjen mukaan',
    'by_sessions'  => 'Istuntojen mukaan',
    'by_users'     => 'Käyttäjien mukaan',
    'no_client_id' => 'Näyttääksesi kävijätilastoja sinulla täytyy olla google analytics client id ja lisätä se '.
                                'asetusriviin avainnimeltään <code>google_analytics_client_id</code>.'.
                                ' Saat idn Google developer konsolista:',
    'set_view'               => 'Valitse näkymä',
    'this_vs_last_week'      => 'Tämä viikko vs viime viikko',
    'this_vs_last_year'      => 'Tämä vuosi vs viime vuosi',
    'top_browsers'           => 'Suosituimmat selaimet',
    'top_countries'          => 'Suosituimmat maat',
    'various_visualizations' => 'Monia eri visualisointeja',
];
