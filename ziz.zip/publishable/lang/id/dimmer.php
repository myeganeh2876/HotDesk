<?php

return [
    'page'           => 'Halaman',
    'page_link_text' => 'Lihat semua halaman',
    'page_text'      => 'Kamu mempunyai :count :string dalam database. Klik tombol dibawah untuk melihat semua halaman.',
    'post'           => 'Post',
    'post_link_text' => 'Lihat semua post',
    'post_text'      => 'Kamu mempunyai :count :string dalam database. Klik tombol dibawah untuk melihat semua post.',
    'user'           => 'User',
    'user_link_text' => 'Lihat semua user',
    'user_text'      => 'Kamu mempunyai :count :string dalam database. Klik tombol dibawah untuk melihat semua user.',
];
