<?php

return [
    'field_password_keep'          => 'Kosongkan untuk menggunakan data yang sama',
    'field_select_dd_relationship' => 'Pastikan untuk mengatur relationship yang benar pada memthod :method dari '.
                                      'class :class .',
    'type_checkbox'       => 'Check Box',
    'type_codeeditor'     => 'Code Editor',
    'type_file'           => 'File',
    'type_image'          => 'Image',
    'type_radiobutton'    => 'Radio Button',
    'type_richtextbox'    => 'Rich Textbox',
    'type_selectdropdown' => 'Select Dropdown',
    'type_textarea'       => 'Text Area',
    'type_textbox'        => 'Text Box',
];
