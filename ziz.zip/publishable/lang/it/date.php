<?php

return [
    'last_week' => 'Ultima Settimana',
    'last_year' => 'Ultimo Anno',
    'this_week' => 'Questa Settimana',
    'this_year' => 'Questo Anno',
];
