<?php

return [
    'page'				        => 'Sida|Sidor',
    'page_link_text' 	=> 'Visa alla sidor',
    'page_text' 		    => 'Du har :count :string i din databas. Klicka på knappen nedan för att visa alla.',
    'post' 				       => 'Post|Poster',
    'post_link_text' 	=> 'Visa all poster',
    'post_text' 		    => 'Du har :count :string i din databas. Klicka på knappen nedan för att visa alla.',
    'user' 				       => 'Användare|Användare',
    'user_link_text' 	=> 'Visa alla användare',
    'user_text' 		    => 'Du har :count :string i din databas. Klicka på knappen nedan för att visa alla posanvändareter.',
];
