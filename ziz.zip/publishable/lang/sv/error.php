<?php

return [
    'symlink_created_text' 		 => 'Vi har just skapat den saknade symboliska länken för dig.',
    'symlink_created_title' 	 => 'Den saknade symboliska länken för lagringsutrymmet skapad',
    'symlink_failed_text' 		  => 'Kunde inte skapa den saknade symboliska länken. Verkar som ditt webbhotell inte stödjer detta.',
    'symlink_failed_title' 		 => 'Kunde inte skapa den saknade symboliska länken',
    'symlink_missing_button' 	=> 'Fixa det!',
    'symlink_missing_text' 		 => 'Vi kunde inte hitta någon symbolisk länk. Detta kan ställa till med problem om media ska laddas i din webbläsare.',
    'symlink_missing_title' 	 => 'Symbolisk länk saknas',
];
