<?php

return [
    'loggingin' 		   => 'Logga in',
    'signin_below' 		=> 'Logga in nedan:',
    'welcome' 			    => 'Välkommen till Voyager. Den saknade Admin-panelen för Laravel',
];
